# Dipesh Sapkota — Portfolio

A static website ready for GitHub Pages.

## Publish for free
1. Create a GitHub account.
2. Create a **public** repository named `YOUR-USERNAME.github.io` (replace YOUR-USERNAME with your actual GitHub username).
3. Upload all files in this folder to the repository root and commit them.
4. Open Settings → Pages and select Deploy from a branch, main, /(root).
5. After deployment, visit https://YOUR-USERNAME.github.io (replace username).

Keep your repository and account active to retain hosting. GitHub's terms and availability can change. A custom domain is optional and normally costs money annually.

To update your website, replace files in the repository and commit. The website currently uses concept portfolio cards; replace them with real work samples as you collect them.
